﻿import React from 'react';
import { FormFilter } from '../FormFilter';
import { shallow } from 'enzyme';
import AppData from '@jsroot/lib/AppData'
import LangHelper from '@jsroot/lib/langHelper';

jest.mock('@jsroot/lib/AppData');

describe('FormFilter ', () => {
    const props = { 
        toggleLoader: jest.fn(), 
        setReportTitle: jest.fn(),
        setRequestParam: jest.fn(),
        getGridData: jest.fn(),
        setSelectedBaseCurrency: jest.fn(),
        setRefno: jest.fn(),
        setUsername: jest.fn(),
        changeIsConvertAll: jest.fn(),
        gridData: [],
        dateRange: { fromDate: '06/01/2018', toDate: '07/27/2018'},
        selectedCurrency:{value: 1},
        isConvertAll: false
    };

    beforeAll(() => {
        LangHelper.getSingleResource = jest.fn((resource) => resource);
        Object.assign(AppData, 
            { 
                baseCurrencyList: [{value: 'EUR', label: 'EUR'}, {value: 'USD', label: 'USD'}], 
                dateConstraint: { minDate: '06/01/2012', maxDate: '07/27/2018', limitedMonthRange: 12 }
            });
    });

    it('render correctly', () => {
        const result = shallow(<FormFilter {...props} />);

        expect(result).toMatchSnapshot();
    });

    it('render Base Currency Select List correctly', () => {
        Object.assign(AppData, { isAllowedCustomerComm: true });

        const filter = new FormFilter(props);
        const result = shallow(<div>{filter._renderBaseCurrencySelectList()}</div>);

        expect(result).toMatchSnapshot();
    });
});